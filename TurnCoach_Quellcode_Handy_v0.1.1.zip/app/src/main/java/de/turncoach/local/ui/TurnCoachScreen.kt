package de.turncoach.local.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import de.turncoach.local.AudioController
import de.turncoach.local.data.GymnastEntity
import de.turncoach.local.data.MusicRepository
import de.turncoach.local.data.MusicRevisionEntity
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TurnCoachScreen(
    repository: MusicRepository,
    incomingUri: Uri?,
    onShareConsumed: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember(repository) { AudioController(context.applicationContext, repository) }
    DisposableEffect(player) { onDispose { player.release() } }

    val gymnasts by repository.watchGymnasts().collectAsState(initial = emptyList())
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    val gymnast = gymnasts.find { it.id == selectedId }
    val tracksFlow = remember(selectedId) {
        selectedId?.let { repository.watchRevisions(it) } ?: flowOf(emptyList())
    }
    val revisions by tracksFlow.collectAsState(initial = emptyList())
    val playingId by player.currentId.collectAsState()
    val isPlaying by player.isPlaying.collectAsState()
    val playerError by player.error.collectAsState()

    var showAddGymnast by remember { mutableStateOf(false) }
    var newGymnastName by remember { mutableStateOf("") }
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    var pendingTitle by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var trackToRestore by remember { mutableStateOf<MusicRevisionEntity?>(null) }
    var trackToExport by remember { mutableStateOf<MusicRevisionEntity?>(null) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pendingUri = uri
            pendingTitle = repository.suggestedFilename(uri).substringBeforeLast('.')
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val destination = result.data?.data
        val track = trackToExport
        if (result.resultCode == Activity.RESULT_OK && destination != null && track != null) {
            scope.launch {
                try { repository.exportRevision(track, destination); errorMessage = "Musik wurde exportiert." }
                catch (e: Exception) { errorMessage = e.message ?: "Export fehlgeschlagen" }
            }
        }
        trackToExport = null
    }

    // Eine über Android/WhatsApp geteilte Datei wird nicht automatisch einem Kind zugeordnet.
    LaunchedEffect(incomingUri, selectedId) {
        if (incomingUri != null && selectedId != null && pendingUri == null) {
            pendingUri = incomingUri
            pendingTitle = repository.suggestedFilename(incomingUri).substringBeforeLast('.')
            onShareConsumed()
        }
    }

    MaterialTheme(colorScheme = lightColorScheme()) {
        Scaffold { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("TurnCoach Local", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Bodenmusik · Lokal auf diesem Gerät", style = MaterialTheme.typography.bodyMedium)
                if (errorMessage != null || playerError != null) {
                    Text(errorMessage ?: playerError.orEmpty(), color = MaterialTheme.colorScheme.error)
                }
                if (incomingUri != null && gymnast == null) {
                    Text("Eine Musikdatei wurde geteilt. Bitte zuerst die passende Turnerin wählen.")
                }
                if (gymnast == null) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Turnerinnen", style = MaterialTheme.typography.titleLarge)
                        Button(onClick = { newGymnastName = ""; showAddGymnast = true }) { Text("+ Hinzufügen") }
                    }
                    if (gymnasts.isEmpty()) Text("Noch keine Turnerinnen angelegt. Zum Start eine Turnerin hinzufügen.")
                    gymnasts.forEach { child ->
                        Card(Modifier.fillMaxWidth().clickable { selectedId = child.id }) {
                            Column(Modifier.padding(16.dp)) {
                                Text(child.name, fontWeight = FontWeight.Bold)
                                Text(if (child.activeTrackId == null) "Noch keine Musik" else "Musik vorhanden · Profil öffnen")
                            }
                        }
                    }
                } else {
                    OutlinedButton(onClick = { player.stop(); selectedId = null }) { Text("← Alle Turnerinnen") }
                    Text(gymnast.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Eine aktive Musik · Frühere Versionen bleiben im Archiv")
                    val active = revisions.find { it.id == gymnast.activeTrackId }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("AKTUELLE BODENMUSIK", style = MaterialTheme.typography.labelLarge)
                            if (active == null) {
                                Text("Noch keine Musik zugeordnet")
                            } else {
                                MusicInfo(active)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { player.playOrPause(active) }) {
                                        Text(if (playingId == active.id && isPlaying) "⏸ Pause" else "▶ Abspielen")
                                    }
                                    OutlinedButton(onClick = { player.stop() }) { Text("■ Stopp") }
                                }
                                TextButton(onClick = { trackToExport = active; launchExport(active) { intent -> exportLauncher.launch(intent) } }) {
                                    Text("Musikdatei exportieren")
                                }
                            }
                            Button(enabled = !busy, onClick = { filePicker.launch(arrayOf("audio/*", "application/octet-stream")) }) {
                                Text("+ Neue Musik zuordnen")
                            }
                        }
                    }
                    Text("Musikhistorie (${revisions.size - if (active != null) 1 else 0})", style = MaterialTheme.typography.titleMedium)
                    val historical = revisions.filter { it.id != gymnast.activeTrackId }
                    if (historical.isEmpty()) Text("Noch keine älteren Versionen")
                    historical.forEach { track ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                MusicInfo(track)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { player.playOrPause(track) }) {
                                        Text(if (playingId == track.id && isPlaying) "⏸ Pause" else "▶ Hören")
                                    }
                                    TextButton(onClick = { trackToRestore = track }) { Text("Aktivieren") }
                                }
                                TextButton(onClick = { trackToExport = track; launchExport(track) { intent -> exportLauncher.launch(intent) } }) {
                                    Text("Datei exportieren")
                                }
                            }
                        }
                    }
                    HorizontalDivider()
                    TextButton(onClick = { confirmDelete = true }) { Text("Turnerinnenprofil und alle Musiken löschen") }
                }
                Spacer(Modifier.height(30.dp))
            }
        }
    }

    if (showAddGymnast) {
        AlertDialog(
            onDismissRequest = { showAddGymnast = false },
            title = { Text("Turnerin hinzufügen") },
            text = { OutlinedTextField(newGymnastName, { newGymnastName = it }, label = { Text("Name") }, singleLine = true) },
            confirmButton = {
                Button(enabled = newGymnastName.isNotBlank(), onClick = {
                    scope.launch {
                        try { selectedId = repository.addGymnast(newGymnastName); showAddGymnast = false }
                        catch (e: Exception) { errorMessage = e.message }
                    }
                }) { Text("Anlegen") }
            },
            dismissButton = { TextButton(onClick = { showAddGymnast = false }) { Text("Abbrechen") } }
        )
    }

    if (pendingUri != null && selectedId != null) {
        val uri = pendingUri!!
        val id = selectedId!!
        AlertDialog(
            onDismissRequest = { if (!busy) pendingUri = null },
            title = { Text("Bodenmusik zuordnen") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Eine bestehende Musik wird automatisch archiviert.")
                    OutlinedTextField(pendingTitle, { pendingTitle = it }, label = { Text("Musiktitel") })
                }
            },
            confirmButton = {
                Button(enabled = !busy, onClick = {
                    busy = true
                    scope.launch {
                        try {
                            repository.importMusic(id, uri, pendingTitle)
                            pendingUri = null
                            errorMessage = "Neue Musik zugeordnet. Alte Version im Archiv."
                            player.stop()
                        } catch (e: Exception) { errorMessage = e.message ?: "Import fehlgeschlagen" }
                        finally { busy = false }
                    }
                }) { Text(if (busy) "Importiere …" else "Zuordnen") }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { pendingUri = null }) { Text("Abbrechen") } }
        )
    }

    trackToRestore?.let { track ->
        AlertDialog(
            onDismissRequest = { trackToRestore = null },
            title = { Text("Ältere Musik reaktivieren?") },
            text = { Text("${track.title} wird als neue Revision übernommen. Die gesamte Historie bleibt erhalten.") },
            confirmButton = { Button(onClick = {
                val id = selectedId ?: return@Button
                scope.launch {
                    try { repository.restoreRevision(id, track.id); player.stop(); errorMessage = "Musik reaktiviert." }
                    catch (e: Exception) { errorMessage = e.message ?: "Fehler" }
                }
                trackToRestore = null
            }) { Text("Reaktivieren") } },
            dismissButton = { TextButton(onClick = { trackToRestore = null }) { Text("Abbrechen") } }
        )
    }

    if (confirmDelete && selectedId != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Profil unwiderruflich löschen?") },
            text = { Text("Alle Versionen der Musikdateien werden ebenfalls gelöscht. Noch keine Backupfunktion vorhanden!") },
            confirmButton = { Button(onClick = {
                val id = selectedId ?: return@Button
                player.stop()
                scope.launch {
                    try { repository.deleteGymnast(id); selectedId = null; errorMessage = "Profil gelöscht." }
                    catch (e: Exception) { errorMessage = e.message }
                }
                confirmDelete = false
            }) { Text("Endgültig löschen") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Abbrechen") } }
        )
    }
}

private fun launchExport(track: MusicRevisionEntity, launch: (Intent) -> Unit) {
    val extension = if (track.mimeType == "audio/mp4") "m4a" else "mp3"
    val safeName = track.title.replace(Regex("[^a-zA-Z0-9äöüÄÖÜß _-]"), "_").take(80)
    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
        addCategory(Intent.CATEGORY_OPENABLE)
        type = track.mimeType
        putExtra(Intent.EXTRA_TITLE, "${safeName}_V${track.revision}.$extension")
    }
    launch(intent)
}

@Composable
private fun MusicInfo(track: MusicRevisionEntity) {
    val fmt = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMANY) }
    Text(track.title, fontWeight = FontWeight.Bold)
    Text("Revision ${track.revision} · ${fmt.format(Date(track.importedAt))}", style = MaterialTheme.typography.bodySmall)
    Text("Original: ${track.originalFilename}", style = MaterialTheme.typography.bodySmall)
    track.restoredFromRevision?.let { Text("Wiederhergestellt aus Revision $it", style = MaterialTheme.typography.bodySmall) }
}
