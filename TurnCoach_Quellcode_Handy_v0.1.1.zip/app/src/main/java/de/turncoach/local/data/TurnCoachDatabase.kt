package de.turncoach.local.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "gymnasts")
data class GymnastEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long,
    val activeTrackId: String? = null
)

@Entity(
    tableName = "music_revisions",
    foreignKeys = [ForeignKey(
        entity = GymnastEntity::class,
        parentColumns = ["id"],
        childColumns = ["gymnastId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("gymnastId")]
)
data class MusicRevisionEntity(
    @PrimaryKey val id: String,
    val gymnastId: String,
    val revision: Int,
    val title: String,
    val originalFilename: String,
    val storedFilename: String,
    val mimeType: String,
    val importedAt: Long,
    val restoredFromRevision: Int? = null
)

@Dao
interface TurnCoachDao {
    @Query("SELECT * FROM gymnasts ORDER BY name COLLATE NOCASE")
    fun watchGymnasts(): Flow<List<GymnastEntity>>

    @Query("SELECT * FROM music_revisions WHERE gymnastId = :gymnastId ORDER BY revision DESC")
    fun watchRevisions(gymnastId: String): Flow<List<MusicRevisionEntity>>

    @Query("SELECT * FROM gymnasts WHERE id = :id LIMIT 1")
    suspend fun getGymnast(id: String): GymnastEntity?

    @Query("SELECT * FROM music_revisions WHERE id = :id LIMIT 1")
    suspend fun getRevision(id: String): MusicRevisionEntity?

    @Query("SELECT * FROM music_revisions WHERE gymnastId = :id")
    suspend fun getRevisions(id: String): List<MusicRevisionEntity>

    @Query("SELECT COALESCE(MAX(revision), 0) FROM music_revisions WHERE gymnastId = :gymnastId")
    suspend fun latestRevision(gymnastId: String): Int

    @Insert suspend fun insertGymnast(gymnast: GymnastEntity)
    @Insert suspend fun insertRevision(revision: MusicRevisionEntity)

    @Query("UPDATE gymnasts SET activeTrackId = :revisionId WHERE id = :gymnastId")
    suspend fun updateActive(gymnastId: String, revisionId: String)

    @Query("DELETE FROM gymnasts WHERE id = :gymnastId")
    suspend fun deleteGymnast(gymnastId: String)
}

@Database(entities = [GymnastEntity::class, MusicRevisionEntity::class], version = 1, exportSchema = false)
abstract class TurnCoachDatabase : RoomDatabase() {
    abstract fun dao(): TurnCoachDao
    companion object {
        @Volatile private var instance: TurnCoachDatabase? = null
        fun get(context: Context): TurnCoachDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, TurnCoachDatabase::class.java, "turncoach-local.db"
            ).build().also { instance = it }
        }
    }
}
