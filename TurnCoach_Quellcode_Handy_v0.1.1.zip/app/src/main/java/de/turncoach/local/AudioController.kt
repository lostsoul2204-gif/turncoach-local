package de.turncoach.local

import android.content.Context
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import de.turncoach.local.data.MusicRepository
import de.turncoach.local.data.MusicRevisionEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Single-track Player: keine Playlist und kein Autostart des nächsten Mädchens. */
class AudioController(context: Context, private val repository: MusicRepository) {
    private val player = ExoPlayer.Builder(context)
        .setHandleAudioBecomingNoisy(true)
        .build().apply {
        setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(),
            true
        )
    }
    private val _currentId = MutableStateFlow<String?>(null)
    val currentId: StateFlow<String?> = _currentId
    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { _isPlaying.value = isPlaying }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) stop()
            }
            override fun onPlayerError(error: PlaybackException) {
                _error.value = "Wiedergabefehler: ${error.errorCodeName}"
                stop()
            }
        })
    }

    fun playOrPause(track: MusicRevisionEntity) {
        if (_currentId.value == track.id) {
            if (player.isPlaying) player.pause() else player.play()
            return
        }
        val file = repository.musicFile(track)
        if (!file.isFile) {
            _error.value = "Die Musikdatei ist nicht mehr vorhanden."
            return
        }
        _error.value = null
        player.stop()
        player.clearMediaItems()
        player.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
        _currentId.value = track.id
        player.prepare()
        player.play()
    }

    fun stop() {
        player.stop()
        player.clearMediaItems()
        _currentId.value = null
        _isPlaying.value = false
    }

    fun release() = player.release()
}
