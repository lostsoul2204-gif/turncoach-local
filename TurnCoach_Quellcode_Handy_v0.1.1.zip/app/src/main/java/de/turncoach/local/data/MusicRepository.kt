package de.turncoach.local.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** Lokaler Speicher: Dateien werden kopiert, nicht nur als fremde URIs gemerkt. */
class MusicRepository(private val context: Context, private val db: TurnCoachDatabase) {
    private val dao = db.dao()
    private val musicDir: File get() = File(context.filesDir, "music").apply { mkdirs() }

    fun watchGymnasts(): Flow<List<GymnastEntity>> = dao.watchGymnasts()
    fun watchRevisions(gymnastId: String): Flow<List<MusicRevisionEntity>> = dao.watchRevisions(gymnastId)

    suspend fun addGymnast(rawName: String): String = withContext(Dispatchers.IO) {
        val name = rawName.trim()
        require(name.isNotBlank() && name.length <= 100) { "Bitte einen gültigen Namen eingeben." }
        val id = UUID.randomUUID().toString()
        dao.insertGymnast(GymnastEntity(id, name, System.currentTimeMillis()))
        id
    }

    fun suggestedFilename(uri: Uri): String {
        var name: String? = null
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) name = cursor.getString(0)
                }
        } catch (_: Exception) { /* Dateiquelle liefert eventuell keinen Namen */ }
        return name?.takeIf { it.isNotBlank() } ?: "Neue Bodenmusik.mp3"
    }

    /** Kopiert die Original-Audiodatei und setzt erst nach erfolgreicher Kopie die aktive Version um. */
    suspend fun importMusic(gymnastId: String, uri: Uri, rawTitle: String): Unit = withContext(Dispatchers.IO) {
        val gymnast = dao.getGymnast(gymnastId) ?: error("Turnerin nicht gefunden")
        val originalFilename = suggestedFilename(uri)
        val ext = originalFilename.substringAfterLast('.', "").lowercase()
        val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
        val knownMp3 = ext == "mp3" || mime == "audio/mpeg" || mime == "audio/mp3"
        val knownM4a = ext == "m4a" || mime == "audio/mp4" || mime == "audio/x-m4a"
        require(knownMp3 || knownM4a) { "Nur MP3- oder M4A-Dateien unterstützt." }
        val title = rawTitle.trim().ifBlank { originalFilename.substringBeforeLast('.') }
        require(title.length <= 140) { "Musiktitel ist zu lang." }
        val filename = "${UUID.randomUUID()}.${if (knownM4a && !knownMp3) "m4a" else "mp3"}"
        val target = File(musicDir, filename)
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(target).use { out ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val read = input.read(buffer)
                        if (read == -1) break
                        total += read
                        require(total <= 60L * 1024 * 1024) { "Datei überschreitet 60 MB." }
                        out.write(buffer, 0, read)
                    }
                    require(total > 0) { "Die Datei ist leer." }
                }
            } ?: error("Datei konnte nicht geöffnet werden.")
            db.withTransaction {
                // Seriennummer bleibt monoton steigend, auch beim Reaktivieren alter Titel.
                val revision = dao.latestRevision(gymnast.id) + 1
                val newEntry = MusicRevisionEntity(
                    id = UUID.randomUUID().toString(), gymnastId = gymnast.id,
                    revision = revision, title = title, originalFilename = originalFilename,
                    storedFilename = filename, mimeType = if (filename.endsWith("m4a")) "audio/mp4" else "audio/mpeg",
                    importedAt = System.currentTimeMillis()
                )
                dao.insertRevision(newEntry)
                dao.updateActive(gymnast.id, newEntry.id)
            }
        } catch (t: Throwable) {
            target.delete()
            throw t
        }
    }

    /** Altes Stück reaktivieren: historische Revision bleibt erhalten, eine NEUE Revision entsteht. */
    suspend fun restoreRevision(gymnastId: String, oldId: String): Unit = withContext(Dispatchers.IO) {
        val old = dao.getRevision(oldId) ?: error("Version nicht gefunden")
        require(old.gymnastId == gymnastId) { "Ungültige Zuordnung" }
        val gymnast = dao.getGymnast(gymnastId) ?: error("Turnerin nicht gefunden")
        require(gymnast.activeTrackId != oldId) { "Version ist bereits aktiv" }
        val source = File(musicDir, old.storedFilename)
        require(source.isFile) { "Audiodatei fehlt." }
        val ext = if (old.mimeType == "audio/mp4") "m4a" else "mp3"
        val filename = "${UUID.randomUUID()}.$ext"
        val destination = File(musicDir, filename)
        try {
            source.copyTo(destination)
            db.withTransaction {
                val newRevision = old.copy(
                    id = UUID.randomUUID().toString(), revision = dao.latestRevision(gymnastId) + 1,
                    storedFilename = filename, importedAt = System.currentTimeMillis(),
                    restoredFromRevision = old.revision
                )
                dao.insertRevision(newRevision)
                dao.updateActive(gymnastId, newRevision.id)
            }
        } catch (t: Throwable) {
            destination.delete()
            throw t
        }
    }

    fun musicFile(revision: MusicRevisionEntity): File = File(musicDir, revision.storedFilename)

    suspend fun exportRevision(revision: MusicRevisionEntity, destination: Uri) = withContext(Dispatchers.IO) {
        val source = musicFile(revision)
        require(source.isFile) { "Die Musikdatei ist nicht mehr vorhanden." }
        context.contentResolver.openOutputStream(destination)?.use { output ->
            source.inputStream().use { it.copyTo(output) }
        } ?: error("Ziel kann nicht beschrieben werden.")
    }

    /** Datenschutz: Profil inkl. aller Musikrevisionen lokal löschen. Vorher sichern! */
    suspend fun deleteGymnast(id: String) = withContext(Dispatchers.IO) {
        val files = dao.getRevisions(id).map { musicFile(it) }
        db.withTransaction { dao.deleteGymnast(id) }
        files.forEach { it.delete() }
    }
}
