package de.turncoach.local

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import de.turncoach.local.data.MusicRepository
import de.turncoach.local.data.TurnCoachDatabase
import de.turncoach.local.ui.TurnCoachScreen

class MainActivity : ComponentActivity() {
    private var sharedUri by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readSharedIntent(intent)
        val repository = MusicRepository(applicationContext, TurnCoachDatabase.get(applicationContext))
        setContent {
            TurnCoachScreen(
                repository = repository,
                incomingUri = sharedUri,
                onShareConsumed = { sharedUri = null }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readSharedIntent(intent)
    }

    @Suppress("DEPRECATION")
    private fun readSharedIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            sharedUri = intent.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
                ?: intent.clipData?.getItemAt(0)?.uri
        }
    }
}
