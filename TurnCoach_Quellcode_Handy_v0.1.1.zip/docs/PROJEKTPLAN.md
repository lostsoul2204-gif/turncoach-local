# TurnCoach Local – Projektauftrag / Stand 16.10.2026

## Ziel
Eigene native Android-App für die lokale Verwaltung von Bodenmusiken im Turntraining.

## Beschlossene Produktregeln
1. Android zuerst; iOS ist ein späteres, optionales Vorhaben.
2. Offline und ohne Cloud-Konto oder laufende Servergebühren.
3. Je Turnerin **eine aktive** Bodenmusik, im Training und Wettkampf identisch.
4. Musiken wechseln gelegentlich; beim Wechsel wird **nicht überschrieben**. Die vorige Musik bleibt dauerhaft im Revisionsarchiv und ist separat hör- und exportierbar.
5. MP3 und M4A, Quelle WhatsApp/Dateien, Wiedergabe über das vom Android-System gewählte Ausgabegerät (JBL Bluetooth).
6. Spätere Erweiterungen: Wettkampfergebnisse, Entwicklung, Notizen, Spracheingabe, Musikvorbereitung für USB.
7. Zentrale SharePoint-/Microsoft-365-Vereinsplattform getrennt behandeln und bis Microsoft-Support-Rückmeldung parken.
8. Minderjährigendaten nur nach Berechtigungs- und Datenschutzklärung; bis dahin fiktive Profile.

## Datenmodell
`Gymnast(id, name, createdAt, activeTrackId)` 1:n `MusicRevision(id, gymnastId, revision, title, originalFilename, storedFilename, mimeType, importedAt, restoredFromRevision)`.
- Der `activeTrackId` zeigt auf genau eine Revision oder NULL.
- Jede neue Zuordnung ist ein neuer Datensatz mit neuer privater Audiodatei.
- Eine erneute Aktivierung einer alten Version erzeugt eine weitere Revision; alte Daten bleiben erhalten.
- Kein MusicRevision-Datensatz wird beim normalen Musikwechsel gelöscht.

## Erste Abnahmetests (mit fiktiven Profilen)
- [ ] A. Neue Turnerin anlegen; Name erscheint nach Neustart der App.
- [ ] B. MP3 per Dateiauswahl importieren und über JBL abspielen.
- [ ] C. M4A importieren, zwei Revisionen sichtbar; nur neue ist aktiv.
- [ ] D. Alte Revision weiterhin hören und exportieren.
- [ ] E. Alte Revision reaktivieren → neuer Revisionseintrag, keine Version geht verloren.
- [ ] F. MP3 aus WhatsApp per Teilen übernehmen; Zuordnung manuell bestätigen.
- [ ] G. Ende eines Liedes startet **keine weitere Musik**.
- [ ] H. Flugmodus: vorhandene Dateien lassen sich weiterhin abspielen.
- [ ] I. Vollständiges verschlüsseltes Backup und Restore implementieren und testen (vor realen Kinderprofilen).
- [ ] J. App-Sperre/Datenschutzkonzept und Freigabe vor produktivem Einsatz.

## Keine falschen Versprechen
- Die Android-Audioausgabe kann von Systemereignissen (Anrufen, Bluetooth-Disconnect etc.) beeinflusst werden.
- M4A ist Container: Abspielbarkeit hängt vom konkreten Codec auf dem Gerät ab; echte Dateien testen.
- Dieser Startstand ist Sourcecode, keine signierte APK und noch kein Buildnachweis.
