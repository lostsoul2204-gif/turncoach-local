# TurnCoach Local – Android-Startprojekt 0.1.1-dev

**Stand: 16. Oktober 2026** · Eigene, lokale Musikverwaltung für das Bodenturnen.

## Was in diesem ersten Quellcode enthalten ist

- Turnerinnen mit Namen anlegen, aufrufen und vollständig entfernen.
- MP3/M4A per Android-Dateiauswahl importieren (Original wird in den privaten App-Speicher kopiert).
- Audio-Dateien aus anderen Android-Apps, z. B. WhatsApp, per **Teilen → TurnCoach Local** annehmen.
- **Pro Turnerin genau eine aktive Musik.** Neue Musik wird zur nächsten Revision, frühere bleiben erhalten.
- Alle Revisionen getrennt abspielen, als Datei exportieren und alte Version als **neue** Revision reaktivieren.
- Wiedergabe direkt über Android-Audioausgabe (also auch über eine gekoppelte JBL-Bluetooth-Box), **keine automatische Titelfolge**.
- Lokale Room-Datenbank; keine Netzberechtigung und keine automatische Android-Cloudsicherung.

## Entwicklungsstand und Sicherheit

**Dies ist ein Entwicklungsprototyp als Quellcode, keine fertig getestete APK.**

Noch NICHT implementiert: geschütztes, vollständiges Backup mit Wiederherstellung, App-Sperre, Datenverschlüsselung auf App-Ebene, Trainerteam-Funktion, Wettkampf-/Trainingsstatistik, Sprachnotizen, Spotify-Anbindung oder iOS. Androids Gerätespeicherverschlüsselung schützt die App-Daten beim gesperrten Gerät abhängig von der Gerätekonfiguration, ist aber kein Ersatz für einen dedizierten App-Zugriffsschutz.

**Bis Backup, Zugriffsschutz und datenschutzrechtliche Abstimmung umgesetzt und geprüft sind, nur fiktive Testprofile verwenden – keine echten Daten von Minderjährigen.**

Die App fordert absichtlich **keine Internetberechtigung** an. Geräteeigene Cloud-Backups und Gerätetransfers sind für die App explizit ausgeschlossen. Werden die App-Daten gelöscht oder die App deinstalliert, gehen die lokalen Daten derzeit verloren. Export der einzelnen Musikdateien ist bereits möglich.

## Lokal in Android Studio starten

1. Ein aktuelles **Android Studio** mit JDK 17, **Android SDK 36** und Gradle 8.13 verwenden.
2. Den gesamten Projektordner öffnen (`File` → `Open`). Die IDE importiert die `settings.gradle.kts`-Datei.
3. **Hinweis:** Die offizielle Gradle-Wrapper-Binärdatei ist in diesem ZIP noch nicht enthalten (hier war keine Gradle-Laufzeit verfügbar). Falls die IDE Gradle nicht selbst einrichtet, lokal Gradle 8.13 installieren und im Projektverzeichnis `gradle wrapper --gradle-version 8.13` ausführen. Dann den Sync wiederholen.
4. Gradle-Synchronisierung mit Internetzugang durchführen, damit Android-Bibliotheken geladen werden.
5. Ein Testhandy mit Android 8+ per USB-Debugging verbinden und die `app`-Konfiguration starten.
6. Testturnerin anlegen, MP3 importieren, zweite Datei importieren, Historie prüfen, alte Revision reaktivieren, beide Musikversionen abspielen und exportieren.

**Hinweis zur Build-Verifikation:** Die Dateien wurden hier strukturell geprüft. Ein tatsächlicher Gradle-Build/Installationstest war mangels Android-SDK/Gradle-Laufzeit nicht möglich; kleinere Buildanpassungen können nötig sein.

## Architektur

- `data/TurnCoachDatabase.kt`: Room-Entities und DAO.
- `data/MusicRepository.kt`: lokale Dateiverwaltung, Import, Export, Revisionierung.
- `AudioController.kt`: Media3-Player mit einer aktiven Audiodatei.
- `ui/TurnCoachScreen.kt`: Compose-Oberfläche inkl. WhatsApp-Share-Import.
- `MainActivity.kt`: Android-Einstiegspunkt und Teilen-Intent.

## Ziele für die nächsten Iterationen

- Vollständiges **passwortgeschütztes Backup und Restore** inklusive Datenbank und Musikversionen, vor realer Nutzung.
- App-Sperre (Gerätebiometrie/PIN) und Datenschutz-/Löschkonzept.
- Verbesserter Musikplayer mit Fortschritt, Zeitposition und optionaler Abschnittswiederholung.
- Musikimport und Metadaten prüfen (WhatsApp-Ausnahmefälle), Praxistest an der JBL.
- Wiedergabeunterbrechungen durch Anrufe/Audiofokus testen.
- Notizen, Wettkampfwertungen und Trends erst nach erfolgreichem Musik-MVP.

Die separate Microsoft-365-Vereinsplattform ist **geparkt** und keine Voraussetzung für diese Anwendung.


## Smartphone-only / Cloud-Build

Anleitung: siehe separate Datei `TurnCoach_Handy_Anleitung.txt`.
GitHub Actions kann eine Debug-APK erzeugen, wenn Quellcode-ZIP und Workflow im privaten Repository liegen.
Warnung: Debug-APK ist nur für Testprofile; wegen wechselnder Signaturschlüssel auf Cloud-Runnern können Folgeversionen ohne feste Signatur eine Deinstallation erfordern.
